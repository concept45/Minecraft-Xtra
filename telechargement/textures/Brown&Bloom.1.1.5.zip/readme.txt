HDCraft V2,4
---------------------------------------------------------------------------------------------------------------------------------------------
-																	    -
- IMPORTANT: None of these textures are made by me, they are taken brom different packs, and i have done small adjustments on some of them. -
-																	    -
---------------------------------------------------------------------------------------------------------------------------------------------
To get rid of the texture glitches:

1) Download HD texture fix by xau here: http://www.minecraftforum.net/viewtopic.php?f=25&t=46173
2) Follow instructions

You also might want to make a backup copy of original minecraft.jar in case something will go wrong. But even if something WILL go wrong or you just won't like this skin, you can always delete the bin folder and Minecraft will automatically re-download the initial files next time you run the application.

------------------------------------------------

Changelog:

V1
- Added cloth, lapis lazuli and the other new textures.

V1,1 
- Fixed the colours of some items and some blocks, including cloth.

V1,2
- Fixed the cloth blocks, and the rest of the items.
- Added pack.png

V1,3
- Made the top of furnaces look brighter.
- Made the dispenser look brighter.
- Added red TNT, and removed the old one.
- Added new flowers.

V1,4
- Added new sandstone texture.

V1,5
- Removed clouds.
- Added new moon.
- Did some small bugfixes on the textures.
- Biome colours got replaced. Brand new textures on both. (Thanks to Scuttles)

V1,6
- Added alot of new paintings. Some made by me, and some made by others.
- Cooked fish doesn't look like sushi anylonger.
- Added new texture for string.
- Added new texture for painting
- Brand new hoe textures.
- Re-added clouds, alternative texture is still there.

V1,7
- Added bed texture
- Added redstone repeater texture
- Added bed item png
- Added redstone repeater png.
- Changed slime ball PNG.
- Added a new particle's png.
- added a shadow png.
- added new cake texture, it finally looks like a normal cake, and not a burnt cake.
- added the mysterious "bleeding obsidian" texture. This texture is temporary.
- Finally added the new cloth texture, it now fits with the colored wool nicely.

V1,8
- Re-added bed item png.
- Re-added repeater png.
- New slimeball png.
Sorry about this, it seems like i forgot to edit the files properly. 

V1,9
- Added new bed texture (From gerudoku texture pack)
- Added new repeater texture (from gerudoku texture pack)
- Fixed the weird redstone lines.
- New bed texture .png (from gerudo texture pack)
- New repeater texture made by me, with a part from Gerudoku pack.
- New pack text. =)

V2,0
- FINALLY added the armor textures, they look much smoother now. Thanks to faithful and his great pack! - http://www.minecraftforum.net/viewtopic.php?f=25&t=77442#screen

V2,1
- Added wolf texture, thanks to Koolwitak and his Mixcraft pack.
- Added cookie texture, thanks to Koolwitak and his Mixcraft pack.
- Added a better squid texture, also from Mixcraft. 

V2,2
- Added two new textures for the new saplings.
- Finally added a arrows.png

V2,3
- Added WildGrass support.

V2,4
- Added the new rails, but the textures are only temporary untill i find some better ones.
- Added grass on the sides of grass-blocks, that fits with biomes.
- Fixed redstone being purple.